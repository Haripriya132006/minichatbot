from flask import Flask, render_template, request, jsonify, send_from_directory
import os
import random
import fitz  #PyMuPDF for PDF processing
import re
from transformers import pipeline
app = Flask(__name__)

FILES_FOLDER = 'files/'  # Folder where files are stored

responses = {
    "hello": ["Hi there!", "Hello!", "Hey! How can I help you?"],
    "how are you": ["I'm good, thank you!", "I'm doing great! How about you?", "I'm just a bot, but I'm doing fine!"],
    "bye": ["Goodbye!", "See you later!", "Bye, have a nice day!"],
    "default": ["Sorry, I don't understand that.", "Can you rephrase?", "I'm not sure how to respond to that."]
}

summarizer = pipeline("summarization", model="facebook/bart-large-cnn")

def extract_text_from_pdf(pdf_path):
    """Extracts text from a PDF file."""
    try:
        doc = fitz.open(pdf_path)
        text = ""
        for page in doc:
            text += page.get_text("text") + "\n"
        return text.strip()
    except Exception as e:
        return f"Error extracting text: {str(e)}"

def summarize_text(text):
    """Summarizes a given text using transformers."""
    if len(text) < 50:
        return "Text is too short for summarization."
    
    # Limiting to the first 1024 tokens to avoid model overload
    text = text[:1024]
    summary = summarizer(text, max_length=150, min_length=50, do_sample=False)
    return summary[0]['summary_text']

def list_files(search=None):
    """List all files in the files folder, optionally filtering by search text."""
    files = os.listdir(FILES_FOLDER)
    if search:
        files = [f for f in files if search.lower() in f.lower()]
    return files


def get_response(user_input):
    """Generate a response based on user input."""
    user_input = user_input.lower()

    
    if "files" in user_input or "show me files" in user_input:
        files = list_files()
        if files:
            # links for files
            links = [
                f'<a href="/files/{file}" target="_blank">{file}</a>' for file in files
            ]
            return "Here are the available files: <br>" + "<br>".join(links), None
        return "No files found in the folder.", None

    if user_input.startswith("open "):
        file_name = user_input.split("open ", 1)[1].strip()
        if os.path.exists(os.path.join(FILES_FOLDER, file_name)):
            return f"Opening file: {file_name}", file_name
        return f"File {file_name} not found.", None

    if user_input.startswith("summarize "):
        file = user_input.split("summarize ", 1)[1].strip()
        text = extract_text_from_pdf(/file)
        summary = summarize_text(text)
        return f"yes i can summarize.",None


    for key in responses:
        if key in user_input:
            return random.choice(responses[key]), None
    return random.choice(responses["default"]), None


@app.route('/')
def index():
    """Render the chatbot interface."""
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    """Handle chat messages and return a response."""
    user_input = request.form['message']
    bot_response, file_to_open = get_response(user_input)
    return jsonify({'response': bot_response, 'file_to_open': file_to_open})

@app.route('/summarize/<filename>')
def summarize_pdf(filename):
    """Extracts and summarizes text from a PDF file."""
    pdf_path = os.path.join(FILES_FOLDER, filename)
    
    if not os.path.exists(pdf_path):
        return jsonify({'error': 'File not found'}), 404

    extracted_text = extract_text_from_pdf(pdf_path)
    if "Error" in extracted_text:
        return jsonify({'error': extracted_text}), 500

    summary = summarize_text(extracted_text)
    return jsonify({'summary': summary})


@app.route('/files/<filename>')
def serve_file(filename):
    return send_from_directory(FILES_FOLDER, filename)

def show_files():
    """Return a list of files available in the files folder."""
    files = list_files()
    if files:
        return "Here are the available files:\n" + "\n".join(files), None
    return "No files found in the folder.", None


if __name__ == '__main__':
    app.run(debug=True) 